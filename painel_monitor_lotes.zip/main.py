
import requests
from bs4 import BeautifulSoup
import json
import os
import streamlit as st

# Configurações do robô
URL = "https://www.gov.br/mcti/pt-br/acompanhe-o-mcti/lei-do-bem/paginas/lotes"
HISTORICO_ARQUIVO = "historico_lotes.json"

st.set_page_config(page_title="Monitor de Lotes - Lei do Bem", layout="wide")
st.title("📡 Monitor de Lotes Publicados - Lei do Bem")

@st.cache_data(ttl=60)
def extrair_lotes():
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        r = requests.get(URL, headers=headers)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, 'html.parser')
        lotes = soup.select("a[href*='lote']")
        links = [lote['href'] for lote in lotes]
        return sorted(list(set(links)), reverse=True)
    except Exception as e:
        st.error(f"Erro ao acessar o site: {e}")
        return []

def carregar_historico():
    try:
        with open(HISTORICO_ARQUIVO, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []

def salvar_historico(lotes):
    with open(HISTORICO_ARQUIVO, "w", encoding="utf-8") as f:
        json.dump(lotes, f, indent=2)

lotes_atuais = extrair_lotes()
lotes_antigos = carregar_historico()
novos = list(set(lotes_atuais) - set(lotes_antigos))

if novos:
    st.success(f"🎉 {len(novos)} novo(s) lote(s) encontrado(s)!")
    for link in sorted(novos, reverse=True):
        st.markdown(f"🔗 [Acessar lote]({link})")
    salvar_historico(lotes_atuais)
else:
    st.info("Nenhum novo lote encontrado desde a última verificação.")

st.divider()
st.subheader("📋 Todos os lotes disponíveis atualmente")
for link in lotes_atuais:
    st.markdown(f"- [Lote]({link})")
